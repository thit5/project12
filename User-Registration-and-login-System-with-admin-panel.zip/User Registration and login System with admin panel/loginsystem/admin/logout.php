<?php
session_start();
session_destroy();
?>
<script language="javascript">
document.location="../index.php";
</script>
